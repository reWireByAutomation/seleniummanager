package org.sm.decode.browsers.firefox;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

public class NoDriverInMachine {


    //No Driver in the host machine
    //Browser is installed in the machine and no version information is provided
    //Firefox Releases: https://ftp.mozilla.org/pub/firefox/releases/
    public static void main(String[] args) throws InterruptedException {
        FirefoxOptions firefoxOptions = new FirefoxOptions();
        firefoxOptions.setPlatformName("Windows");
        WebDriver driver = new FirefoxDriver(firefoxOptions);
        driver.get("https://www.selenium.dev/selenium/web/web-form.html");
        Thread.sleep(2000);
        driver.quit();
    }

}
