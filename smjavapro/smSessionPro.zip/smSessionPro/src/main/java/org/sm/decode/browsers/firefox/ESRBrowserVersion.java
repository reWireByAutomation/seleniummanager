package org.sm.decode.browsers.firefox;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

public class ESRBrowserVersion {

    //ESR - Firefox Extended Support Release
    //Firefox Releases: https://ftp.mozilla.org/pub/firefox/releases/
    public static void main(String[] args) throws InterruptedException {
        FirefoxOptions firefoxOptions = new FirefoxOptions();
        firefoxOptions.setBrowserVersion("esr");
        firefoxOptions.setPlatformName("Windows");
        WebDriver driver = new FirefoxDriver(firefoxOptions);
        driver.get("https://www.selenium.dev/selenium/web/web-form.html");
        Thread.sleep(2000);
        driver.quit();
    }


}
