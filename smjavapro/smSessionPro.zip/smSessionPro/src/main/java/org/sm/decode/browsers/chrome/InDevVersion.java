package org.sm.decode.browsers.chrome;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class InDevVersion {

    //Chrome: CfT Link > https://googlechromelabs.github.io/chrome-for-testing/
    //Chrome Development version is provided as label

    public static void main(String[] args) throws InterruptedException {
        ChromeOptions chromeOptions = new ChromeOptions();
        chromeOptions.setBrowserVersion("dev");
        chromeOptions.setPlatformName("Windows");
        WebDriver driver = new ChromeDriver(chromeOptions);
        driver.get("https://www.selenium.dev/selenium/web/web-form.html");
        Thread.sleep(2000);
        driver.quit();
    }


}
