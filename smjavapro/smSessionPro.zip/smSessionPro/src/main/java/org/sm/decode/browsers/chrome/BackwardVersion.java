package org.sm.decode.browsers.chrome;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class BackwardVersion {

    //Chrome: CfT Link > https://googlechromelabs.github.io/chrome-for-testing/
    //Provide Backward Version of chrome
    public static void main(String[] args) throws InterruptedException {
        ChromeOptions chromeOptions = new ChromeOptions();
        chromeOptions.setBrowserVersion("113");
        chromeOptions.setPlatformName("Windows");
        WebDriver driver = new ChromeDriver(chromeOptions);
        driver.get("https://www.selenium.dev/selenium/web/web-form.html");
        Thread.sleep(2000);
        driver.quit();
    }


}
