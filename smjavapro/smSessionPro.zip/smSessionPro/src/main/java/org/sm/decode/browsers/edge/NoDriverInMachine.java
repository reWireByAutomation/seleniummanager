package org.sm.decode.browsers.edge;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

public class NoDriverInMachine {

    //No Driver in the host machine
    //No Browser Information is provided
    // https://www.microsoft.com/en-us/edge/download

    public static void main(String[] args) throws InterruptedException {
        EdgeOptions edgeOptions = new EdgeOptions();
        edgeOptions.setPlatformName("Windows");
        WebDriver driver = new EdgeDriver(edgeOptions);
        driver.get("https://www.selenium.dev/selenium/web/web-form.html");
        Thread.sleep(2000);
        driver.quit();
    }

}
